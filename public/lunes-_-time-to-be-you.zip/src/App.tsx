import { motion, useScroll, useSpring, useMotionValue, useTransform, AnimatePresence, useAnimationFrame } from "motion/react";
import { ArrowRight, Instagram, Facebook, Mail, X, ArrowUp, Activity, Compass, Leaf, Home, Dumbbell, Anchor, Heart, Bed } from "lucide-react";
import { useRef, useState, useEffect } from "react";

const LunesLogo = ({ className = "" }: { className?: string }) => (
  <svg viewBox="0 0 280 60" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* L */}
    <path d="M10 5H15V50H45V55H10V5Z" fill="currentColor" />
    {/* U */}
    <path d="M60 5H65V40C65 48 71 54 79 54C87 54 93 48 93 40V5H98V40C98 51 90 60 79 60C68 60 60 51 60 40V5Z" fill="currentColor" />
    {/* N - The stylized version */}
    <path d="M115 5H120V55H115V5Z" fill="currentColor" />
    <path d="M155 5H160V55H155V5Z" fill="currentColor" />
    <path d="M118 8L157 52V58L118 14V8Z" fill="currentColor" />
    {/* E */}
    <path d="M180 5H220V10H185V27H215V32H185V50H220V55H180V5Z" fill="currentColor" />
    {/* S */}
    <path d="M265 15C265 9 260 5 252 5C244 5 238 9 238 15C238 21 243 24 252 27C261 30 266 33 266 40C266 47 260 52 252 52C244 52 238 47 238 40H243C243 45 247 48 252 48C257 48 261 45 261 40C261 35 256 32 247 29C238 26 233 23 233 15C233 8 239 2 252 2C265 2 270 8 270 15H265Z" fill="currentColor" />
  </svg>
);

const SUB_BRANDS = [
  {
    id: "move",
    title: "LUNES MOVE",
    subtitle: "Movimento com Alma",
    description: "Mais do que um treino funcional, o nosso espaço Boutique é um ponto de encontro familiar. Onde o corpo é desafiado através da técnica e da comunidade. É o movimento que liberta a mente e fortalece o espírito.",
    details: [
      "Treino Personalizado e Funcional",
      "Comunidade e Networking",
      "Equipamentos de Alta Performance",
      "Eventos de Bem-Estar Mensais"
    ],
    color: "bg-move-citrus",
    textColor: "text-move-leaf",
    accentBorder: "hover:border-move-citrus",
    accentShadow: "shadow-move-citrus/20",
    icon: <Activity className="w-6 h-6" />,
    gradient: "lunes-gradient-move",
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=1200&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: "explore",
    title: "LUNES EXPLORE",
    subtitle: "A Liberdade do Horizonte",
    description: "A exploração acontece onde a terra termina e a água começa. Através de experiências náuticas curadas, convidamos a explorar o mundo exterior para redescobrir o seu mundo interior.",
    details: [
      "Expedições Náuticas Curadas",
      "Workshops de Navegação",
      "Retiros em Alto Mar",
      "Conexão com a Natureza Selvagem"
    ],
    color: "bg-explore-cyan",
    textColor: "text-explore-blue",
    accentBorder: "hover:border-explore-cyan",
    accentShadow: "shadow-explore-cyan/20",
    icon: <Compass className="w-6 h-6" />,
    gradient: "lunes-gradient-explore",
    image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=1200&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1516939884455-1445c8652f83?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1464947644273-914a94b3f034?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: "feel",
    title: "LUNES FEEL",
    subtitle: "A Raiz e a Nutrição",
    description: "A verdadeira sofisticação reside no orgânico. No nosso espaço de campo e agricultura bio, o FEEL traduz-se no toque da terra e no sabor do produto honesto. Um regresso aos sentidos.",
    details: [
      "Agricultura Biológica Certificada",
      "Experiências Farm-to-Table",
      "Workshops de Culinária Consciente",
      "Turismo Rural de Luxo"
    ],
    color: "bg-feel-athletics",
    textColor: "text-feel-sage",
    accentBorder: "hover:border-feel-athletics",
    accentShadow: "shadow-feel-athletics/20",
    icon: <Leaf className="w-6 h-6" />,
    gradient: "lunes-gradient-feel",
    image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?q=80&w=1200&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1464226184884-fa280b87c399?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1523348830342-d01f9fc9d55e?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: "stay",
    title: "LUNES STAY",
    subtitle: "O Refúgio do Ser",
    description: "O nosso alojamento local é a materialização física desta identidade visual: espaços amplos, luz natural e uma calma regeneradora. Um lugar desenhado para 'estar', sem a urgência de 'fazer'.",
    details: [
      "Design Minimalista e Funcional",
      "Ambientes de Silêncio Curado",
      "Integração com a Paisagem",
      "Serviço de Concierge Personalizado"
    ],
    color: "bg-stay-creame",
    textColor: "text-stay-pink",
    accentBorder: "hover:border-stay-creame",
    accentShadow: "shadow-stay-creame/20",
    icon: <Home className="w-6 h-6" />,
    gradient: "lunes-gradient-stay",
    image: "https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?q=80&w=1200&auto=format&fit=crop",
    gallery: [
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1433838552652-f9a46b332c40?q=80&w=800&auto=format&fit=crop"
    ]
  }
];

const TESTIMONIALS = [
  {
    name: "Sofia Martins",
    role: "LUNES MOVE Member",
    quote: "A LUNES não é apenas um ginásio, é onde encontro o meu equilíbrio semanal. O ambiente é acolhedor e os treinos são desafiantes mas respeitam o meu ritmo.",
    image: "https://i.pravatar.cc/150?u=sofia"
  },
  {
    name: "Ricardo Silva",
    role: "LUNES EXPLORE Guest",
    quote: "A expedição náutica foi transformadora. Estar em alto mar, com o silêncio curado da LUNES, permitiu-me reconectar com o que realmente importa.",
    image: "https://i.pravatar.cc/150?u=ricardo"
  },
  {
    name: "Ana Oliveira",
    role: "LUNES STAY Resident",
    quote: "Ficar no alojamento da LUNES foi como respirar pela primeira vez em meses. O design minimalista e a luz natural criam uma paz indescritível.",
    image: "https://i.pravatar.cc/150?u=ana"
  }
];

const MANIFESTO_CARDS = [
  { id: 1, title: "Manifesto", image: "https://picsum.photos/seed/lunes-abstract/800/1000" },
  { id: 2, title: "MOVE", image: "https://picsum.photos/seed/lunes-move/800/1000" },
  { id: 3, title: "EXPLORE", image: "https://picsum.photos/seed/lunes-explore/800/1000" },
  { id: 4, title: "STAY", image: "https://picsum.photos/seed/lunes-stay/800/1000" },
  { id: 5, title: "EAT", image: "https://picsum.photos/seed/lunes-eat/800/1000" },
];

const ManifestoStack = () => {
  const [cards, setCards] = useState(MANIFESTO_CARDS);

  const rotateCards = () => {
    setCards((prev) => {
      const newCards = [...prev];
      const first = newCards.shift();
      if (first) newCards.push(first);
      return newCards;
    });
  };

  return (
    <div 
      className="relative w-full aspect-[4/5] cursor-pointer group" 
      onClick={rotateCards}
    >
      <AnimatePresence mode="popLayout">
        {cards.map((card, index) => (
          <motion.div
            key={card.id}
            layout
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ 
              scale: 1 - index * 0.05, 
              opacity: 1 - index * 0.2,
              y: index * 15,
              zIndex: MANIFESTO_CARDS.length - index,
              rotate: index % 2 === 0 ? index * 1.5 : -index * 1.5
            }}
            exit={{ x: 400, opacity: 0, rotate: 25, transition: { duration: 0.4 } }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="absolute inset-0 rounded-[2.5rem] overflow-hidden shadow-2xl border border-white/10 bg-blackout"
          >
            <img 
              src={card.image} 
              alt={card.title} 
              className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blackout/60 via-transparent to-transparent" />
            <div className="absolute bottom-10 left-10">
              <span className="text-[10px] uppercase tracking-[0.6em] text-coconut/80 font-bold">{card.title}</span>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
      
      {/* Interaction Hint */}
      <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 flex items-center gap-2 opacity-30 group-hover:opacity-60 transition-opacity">
        <span className="text-[9px] uppercase tracking-widest">Clique para rodar</span>
        <ArrowRight className="w-3 h-3" />
      </div>
    </div>
  );
};

export default function App() {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  // Dynamic color for the progress ring based on scroll
  const ringColor = useTransform(
    scrollYProgress,
    [0, 0.2, 0.4, 0.6, 0.8, 1],
    ["#FBF9F9", "#C3EA4F", "#D0EFEF", "#EAEACB", "#F7EADF", "#FBF9F9"]
  );

  const ringOpacity = useTransform(
    scrollYProgress,
    [0, 0.1, 0.9, 1],
    [0.3, 0.8, 0.8, 0.3]
  );

  // Interactive Logic
  const rotationValue = useMotionValue(0);
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  
  const springConfig = { damping: 30, stiffness: 100 };
  const smoothMouseX = useSpring(mouseX, springConfig);
  const smoothMouseY = useSpring(mouseY, springConfig);

  const [selectedBrand, setSelectedBrand] = useState<typeof SUB_BRANDS[0] | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  const cardTransition = {
    type: "spring",
    damping: 25,
    stiffness: 120,
    mass: 0.8,
  };

  const sharedTransition = {
    type: "spring",
    damping: 30,
    stiffness: 100,
    mass: 1,
  };

  // Scroll tracking for header and scroll-to-top button
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Mouse tracking for parallax effects
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set((e.clientX / window.innerWidth - 0.5) * 20);
      mouseY.set((e.clientY / window.innerHeight - 0.5) * 20);
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [mouseX, mouseY]);

  // Auto-rotation effect
  useAnimationFrame((time) => {
    rotationValue.set(time * 0.01);
  });

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen selection:bg-blackout selection:text-coconut" ref={containerRef}>
      <motion.div
        animate={{
          scale: selectedBrand ? 0.98 : 1,
          filter: selectedBrand ? "blur(10px)" : "blur(0px)",
          opacity: selectedBrand ? 0.6 : 1,
        }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        {/* Navigation */}
      <nav className={`fixed top-0 left-0 w-full z-50 px-8 transition-all duration-500 flex justify-between items-center text-coconut ${
        isScrolled 
          ? "bg-blackout/90 backdrop-blur-lg py-4 border-b border-coconut/10 shadow-2xl" 
          : "py-6 mix-blend-difference"
      }`}>
        <div className="flex items-center gap-4 cursor-pointer group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <div className="relative w-10 h-10 flex items-center justify-center">
            {/* Scroll Progress Ring */}
            <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 40 40">
              <motion.circle
                cx="20"
                cy="20"
                r="18"
                fill="none"
                stroke={ringColor}
                strokeWidth="2"
                strokeDasharray="113.1"
                style={{ 
                   pathLength: scrollYProgress,
                   opacity: ringOpacity
                }}
                transition={{ duration: 0.5 }}
              />
              {/* Background Ring */}
              <circle
                cx="20"
                cy="20"
                r="18"
                fill="none"
                stroke="currentColor"
                strokeWidth="1"
                className="opacity-10"
              />
            </svg>
            <div className="w-5 h-5 flex items-center justify-center group-hover:drop-shadow-[0_0_8px_rgba(251,249,249,0.5)] transition-all overflow-hidden">
              <LunesLogo className="w-[140px] h-auto -translate-x-[5px]" />
            </div>
          </div>
          <LunesLogo className="h-5 w-auto group-hover:drop-shadow-[0_0_10px_rgba(251,249,249,0.6)] transition-all" />
        </div>
        <div className="hidden md:flex gap-6 text-[10px] uppercase tracking-widest font-bold">
          <button 
            onClick={() => scrollToSection('about')} 
            className="hover:text-coconut hover:drop-shadow-[0_0_10px_rgba(251,249,249,0.6)] transition-all px-3 py-1"
          >
            SOBRE
          </button>
          <button 
            onClick={() => setSelectedBrand(SUB_BRANDS.find(b => b.id === 'move') || null)} 
            className="hover:text-move-leaf hover:bg-move-citrus hover:shadow-[0_0_25px_rgba(195,234,79,0.5)] transition-all px-4 py-1.5 rounded-full"
          >
            MOVE
          </button>
          <button 
            onClick={() => setSelectedBrand(SUB_BRANDS.find(b => b.id === 'explore') || null)} 
            className="hover:text-explore-blue hover:bg-explore-cyan hover:shadow-[0_0_25px_rgba(208,239,239,0.5)] transition-all px-4 py-1.5 rounded-full"
          >
            EXPLORE
          </button>
          <button 
            onClick={() => setSelectedBrand(SUB_BRANDS.find(b => b.id === 'feel') || null)} 
            className="hover:text-feel-sage hover:bg-feel-athletics hover:shadow-[0_0_25px_rgba(234,234,203,0.5)] transition-all px-4 py-1.5 rounded-full"
          >
            FEEL
          </button>
          <button 
            onClick={() => setSelectedBrand(SUB_BRANDS.find(b => b.id === 'stay') || null)} 
            className="hover:text-stay-pink hover:bg-stay-creame hover:shadow-[0_0_25px_rgba(247,234,223,0.5)] transition-all px-4 py-1.5 rounded-full"
          >
            STAY
          </button>
        </div>
        <button 
          onClick={() => scrollToSection('contact')}
          className="border border-coconut/30 rounded-full px-6 py-2 text-[10px] uppercase tracking-widest hover:bg-coconut hover:text-blackout transition-all bg-blackout/40 backdrop-blur-sm hover:shadow-[0_0_25px_rgba(251,249,249,0.5)] border-b-2 border-r-2"
        >
          Contacto
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex flex-col items-center justify-center bg-blackout text-coconut overflow-hidden select-none">
        {/* YouTube Background Video */}
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[115vw] h-[115vh] min-w-[177.77vh] min-h-[56.25vw]">
            <iframe
              src="https://www.youtube.com/embed/5ZBRAddjwwU?autoplay=1&mute=1&loop=1&controls=0&showinfo=0&autohide=1&modestbranding=1&playlist=5ZBRAddjwwU&rel=0&enablejsapi=1"
              className="w-full h-full pointer-events-none opacity-30 grayscale contrast-125 scale-110"
              allow="autoplay; encrypted-media"
              title="Lunes Background Video"
            />
          </div>
          {/* Dark Overlay for Readability */}
          <div className="absolute inset-0 bg-blackout/40" />
        </div>

        {/* Grainy Cinematic Overlay */}
        <div className="absolute inset-0 z-[1] opacity-[0.03] pointer-events-none mix-blend-overlay bg-[url('https://grainy-gradients.vercel.app/noise.svg')] will-change-opacity" />

        {/* 2026 Atmospheric Background: Liquid Aura & Micro-moments */}
        <div className="absolute inset-0 z-[2] pointer-events-none overflow-hidden">
          {/* Generative Aura */}
          <motion.div 
            style={{
              x: useTransform(smoothMouseX, (v) => v * -1.5),
              y: useTransform(smoothMouseY, (v) => v * -1.5),
            }}
            animate={{ 
              scale: [1, 1.15, 1],
              rotate: [0, 90, 180, 270, 360],
              opacity: selectedBrand ? 0.4 : 0.15,
            }}
            transition={{ 
              scale: { duration: 20, repeat: Infinity, ease: "linear" },
              rotate: { duration: 25, repeat: Infinity, ease: "linear" },
            }}
            className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110vw] h-[110vw] rounded-full blur-[100px] transition-colors duration-1000 will-change-transform ${selectedBrand ? selectedBrand.color : 'bg-coconut/10'}`}
          />
          
          {/* Secondary Aura for Depth */}
          <motion.div 
            style={{
              x: useTransform(smoothMouseX, (v) => v * 0.8),
              y: useTransform(smoothMouseY, (v) => v * 0.8),
            }}
            animate={{ 
              scale: [1.2, 1, 1.2],
              rotate: [360, 270, 180, 90, 0],
              opacity: 0.05,
            }}
            transition={{ 
              scale: { duration: 30, repeat: Infinity, ease: "linear" },
              rotate: { duration: 30, repeat: Infinity, ease: "linear" },
            }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90vw] h-[90vw] rounded-full blur-[120px] bg-coconut/5 will-change-transform"
          />

          {/* Micro-moments (Particles) */}
          {[...Array(30)].map((_, i) => {
            const size = Math.random() * 2 + 0.5;
            const speed = Math.random() * 20 + 15;
            const initialX = Math.random() * 100;
            const initialY = Math.random() * 100;
            const parallaxFactor = size * 0.8;
            const twinkleDuration = Math.random() * 3 + 2;

            return (
              <motion.div
                key={i}
                initial={{ 
                  x: initialX + "vw", 
                  y: initialY + "vh",
                  opacity: 0
                }}
                style={{
                  translateX: useTransform(smoothMouseX, (v) => v * parallaxFactor),
                  translateY: useTransform(smoothMouseY, (v) => v * parallaxFactor),
                  width: size, 
                  height: size,
                  filter: size > 1.5 ? 'blur(0.5px)' : 'none'
                }}
                animate={{ 
                  y: [null, -300],
                  opacity: [0, 0.6, 0.2, 0.6, 0],
                }}
                transition={{ 
                  y: { duration: speed, repeat: Infinity, ease: "linear", delay: Math.random() * 10 },
                  opacity: { 
                    duration: twinkleDuration, 
                    repeat: Infinity, 
                    ease: "easeInOut",
                    times: [0, 0.2, 0.5, 0.8, 1]
                  },
                }}
                className="absolute rounded-full bg-coconut shadow-[0_0_8px_rgba(251,249,249,0.4)] will-change-transform"
              />
            );
          })}
        </div>

        {/* Interaction Layer */}
        <motion.div 
          className="absolute inset-0 z-20 cursor-default"
          onClick={() => selectedBrand && setSelectedBrand(null)}
        />

        {/* Content Container */}
        <div className="relative z-30 flex flex-col items-center gap-16">
          <motion.div 
            initial={{ opacity: 0, filter: "blur(20px)" }}
            animate={{ 
              opacity: selectedBrand ? 0 : 1, 
              filter: selectedBrand ? "blur(20px)" : "blur(0px)",
              y: selectedBrand ? -40 : 0
            }}
            transition={{ 
              opacity: { duration: 1.2, ease: [0.16, 1, 0.3, 1] },
              filter: { duration: 1.2, ease: [0.16, 1, 0.3, 1] },
              y: { duration: 1.2, ease: [0.16, 1, 0.3, 1] }
            }}
            className="text-center pointer-events-none"
          >
            <h1 className="text-[12vw] md:text-[10vw] leading-none mb-6 italic tracking-tighter font-serif drop-shadow-2xl">
              Time to be You.
            </h1>
            <div className="flex items-center justify-center gap-4 opacity-40">
              <p className="text-[10px] md:text-xs uppercase tracking-[0.6em] font-light">
                O teu momento, a tua essência
              </p>
            </div>
          </motion.div>

          <motion.button
            initial={{ opacity: 0, filter: "blur(10px)" }}
            animate={{ 
              opacity: selectedBrand ? 0 : 1,
              filter: selectedBrand ? "blur(10px)" : "blur(0px)",
              y: selectedBrand ? 20 : 0
            }}
            transition={{ delay: 0.5, duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            onClick={() => scrollToSection('about')}
            className="group flex flex-col items-center gap-4 cursor-pointer pointer-events-auto"
          >
            <div className="w-[1.5px] h-24 bg-gradient-to-b from-coconut/0 via-coconut/100 to-coconut/0 shadow-[0_0_15px_rgba(251,249,249,0.6)] group-hover:shadow-[0_0_25px_rgba(251,249,249,0.8)] transition-all" />
            <span className="text-[10px] uppercase tracking-[0.4em] opacity-40 group-hover:opacity-100 transition-opacity group-hover:text-coconut group-hover:drop-shadow-[0_0_12px_rgba(251,249,249,0.8)]">Descobrir</span>
          </motion.button>
        </div>

        <motion.div 
          style={{ rotate: scrollYProgress }}
          className="absolute w-[80vw] h-[80vw] border border-coconut/5 rounded-full -bottom-[40vw] z-0"
        />
      </section>

      {/* Sub-brands Grid */}
      <section className="py-32 px-8 bg-coconut overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
            <div className="space-y-4">
              <h2 className="text-5xl md:text-7xl italic leading-tight">O Nosso Ecossistema</h2>
              <p className="text-blackout/60 max-w-md uppercase tracking-widest text-[10px]">Quatro pilares, uma única essência.</p>
            </div>
            <div className="hidden md:block w-24 h-[1px] bg-blackout/20 mb-4" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {SUB_BRANDS.map((brand, idx) => (
              <motion.div
                key={brand.id}
                layoutId={`card-${brand.id}`}
                whileHover="hover"
                initial="initial"
                onClick={() => setSelectedBrand(brand)}
                className="group relative h-[650px] rounded-[2rem] overflow-hidden cursor-pointer bg-blackout"
                transition={cardTransition}
              >
                {/* Background Image - Hero of the card */}
                <motion.img 
                  layoutId={`img-${brand.id}`}
                  src={brand.image} 
                  alt={brand.title}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2000ms] ease-out"
                  referrerPolicy="no-referrer"
                  transition={cardTransition}
                />
                
                {/* Minimalist Editorial Overlay */}
                <motion.div 
                  layoutId={`overlay-${brand.id}`}
                  className="absolute inset-0 bg-gradient-to-t from-blackout/90 via-transparent to-transparent opacity-30 group-hover:opacity-60 transition-opacity duration-1000" 
                  transition={cardTransition}
                />
                
                {/* Content Overlay */}
                <div className="absolute inset-0 p-8 flex flex-col justify-between z-10">
                  <div className="flex justify-between items-start">
                    <motion.div 
                      variants={{
                        hover: { scale: 1.1, rotate: -5, transition: { type: "spring", stiffness: 400 } }
                      }}
                      className={`p-3 rounded-xl ${brand.color} ${brand.textColor} shadow-2xl backdrop-blur-md bg-opacity-80`}
                    >
                      {brand.icon}
                    </motion.div>
                    <span className="text-[10px] font-mono opacity-30 text-coconut tracking-[0.4em]">0{idx + 1}</span>
                  </div>
                  
                  <div className="space-y-1">
                    <motion.p 
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.1, duration: 0.8 }}
                      className="text-[8px] uppercase tracking-[0.8em] text-coconut/40 font-bold mb-2"
                    >
                      {brand.subtitle}
                    </motion.p>
                    <h3 className="text-5xl md:text-6xl text-coconut italic leading-[0.8] font-serif tracking-tighter">
                      {brand.title.replace('LUNES ', '')}
                    </h3>
                    <motion.div 
                      initial={{ opacity: 0, width: 0 }}
                      whileInView={{ opacity: 1, width: "100%" }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.3, duration: 1 }}
                      className="flex items-center gap-4 pt-6 opacity-0 group-hover:opacity-100 transition-all duration-700 translate-y-4 group-hover:translate-y-0"
                    >
                      <div className={`h-[1px] w-8 ${brand.color}`} />
                      <span className="text-[8px] uppercase tracking-[0.5em] text-coconut/60">Descobrir</span>
                      <ArrowRight className="w-3 h-3 text-coconut -rotate-45 opacity-60" />
                    </motion.div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-32 px-8 max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <div className="space-y-8">
          <h2 className="text-5xl md:text-7xl leading-tight">
            Visualmente somos o branco que traz clareza ao caos.
          </h2>
          <p className="text-lg text-blackout/70 leading-relaxed font-light">
            A LUNES captura o simbolismo da segunda-feira, o dia dos novos começos, e transforma-o numa celebração do “Eu”. Representamos a individualidade e a autenticidade como o centro de tudo.
          </p>
          <div className="pt-4">
            <button 
              onClick={() => scrollToSection('contact')}
              className="flex items-center gap-4 text-xs uppercase tracking-widest font-bold hover:gap-6 transition-all"
            >
              <span>Explorar Manifesto</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="relative px-12 md:px-0">
          <ManifestoStack />
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-32 bg-blackout/5">
        <div className="max-w-7xl mx-auto px-8">
          <div className="text-center mb-24 space-y-4">
            <h2 className="text-5xl md:text-7xl italic">Vozes da Comunidade</h2>
            <p className="text-xs uppercase tracking-[0.5em] opacity-40">O que dizem sobre a experiência LUNES</p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            {TESTIMONIALS.map((t, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, filter: "blur(15px)" }}
                whileInView={{ opacity: 1, filter: "blur(0px)" }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2, duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                className="bg-white p-12 rounded-[3rem] shadow-sm hover:shadow-xl transition-all duration-500 group"
              >
                <div className="mb-8">
                  <div className="w-16 h-16 rounded-full overflow-hidden mb-6 grayscale group-hover:grayscale-0 transition-all duration-500">
                    <img 
                      src={t.image} 
                      alt={t.name} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <h3 className="text-xl font-serif italic">{t.name}</h3>
                  <p className="text-[10px] uppercase tracking-widest opacity-40">{t.role}</p>
                </div>
                <p className="text-lg leading-relaxed text-blackout/70 font-light italic">
                  "{t.quote}"
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-blackout text-coconut pt-32 pb-12 px-8">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-16 mb-32">
          <div className="col-span-2 space-y-8">
            <LunesLogo className="h-12 w-auto" />
            <p className="text-coconut/80 max-w-md font-light">
              LUNES não vende tempo. LUNES devolve o tempo. Junte-se à nossa comunidade e redescubra o seu ritmo natural.
            </p>
            <div className="flex gap-6">
              <Instagram className="w-5 h-5 opacity-80 hover:opacity-100 cursor-pointer transition-opacity" />
              <Facebook className="w-5 h-5 opacity-80 hover:opacity-100 cursor-pointer transition-opacity" />
              <Mail className="w-5 h-5 opacity-80 hover:opacity-100 cursor-pointer transition-opacity" />
            </div>
          </div>
          
          <div className="space-y-6">
            <h4 className="text-xs uppercase tracking-widest font-bold">Links</h4>
            <ul className="space-y-4 text-sm text-coconut/70">
              <li className="relative w-fit hover:text-coconut cursor-pointer transition-colors group">
                Carreiras
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-coconut transition-all duration-300 group-hover:w-full" />
              </li>
              <li className="relative w-fit hover:text-coconut cursor-pointer transition-colors group">
                Imprensa
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-coconut transition-all duration-300 group-hover:w-full" />
              </li>
              <li className="relative w-fit hover:text-coconut cursor-pointer transition-colors group">
                Privacidade
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-coconut transition-all duration-300 group-hover:w-full" />
              </li>
              <li className="relative w-fit hover:text-coconut cursor-pointer transition-colors group">
                Termos
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-coconut transition-all duration-300 group-hover:w-full" />
              </li>
            </ul>
          </div>

          <div className="space-y-6">
            <h4 className="text-xs uppercase tracking-widest font-bold">Newsletter</h4>
            <p className="text-sm text-coconut/70">Receba inspiração semanal para o seu bem-estar.</p>
            <div className="flex border-b border-coconut/20 py-2">
              <input 
                type="email" 
                placeholder="O seu email" 
                className="bg-transparent border-none outline-none text-sm w-full placeholder:text-coconut/40"
              />
              <ArrowRight className="w-4 h-4 opacity-80" />
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-12 border-t border-coconut/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] uppercase tracking-widest opacity-60">
          <span>©2026 LUNES. Todos os direitos reservados.</span>
          <span>BELUNES.PT</span>
          <span>Designed for Authenticity</span>
        </div>
      </footer>
      </motion.div>

      {/* Information Panel (Full Screen Overlay) */}
      <AnimatePresence>
        {selectedBrand && (
          <motion.div
            layoutId={`card-${selectedBrand.id}`}
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            transition={{ 
              type: "spring", 
              damping: 30, 
              stiffness: 150, 
              mass: 0.8 
            }}
            className="fixed inset-0 z-[100] bg-coconut/95 backdrop-blur-3xl text-blackout overflow-y-auto"
          >
            <div className="min-h-screen flex flex-col">
              {/* Header / Close Button */}
              <div className="p-8 md:p-12 flex justify-between items-center">
                <LunesLogo className={`h-6 w-auto ${selectedBrand.textColor}`} />
                <button 
                  onClick={() => setSelectedBrand(null)}
                  className={`p-4 hover:bg-blackout/5 rounded-full transition-colors group ${selectedBrand.textColor}`}
                >
                  <X className="w-8 h-8 group-hover:rotate-90 transition-transform duration-300" />
                </button>
              </div>

              <div className="flex-grow max-w-7xl mx-auto px-8 md:px-16 py-12 grid lg:grid-cols-2 gap-20 items-start">
                <div className="space-y-12">
                  <motion.div 
                    initial={{ opacity: 0, filter: "blur(10px)", y: 20 }}
                    animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                    transition={{ delay: 0.2, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className="space-y-4"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`p-4 rounded-2xl ${selectedBrand.color} ${selectedBrand.textColor}`}>
                        {selectedBrand.icon}
                      </div>
                      <p className="text-sm uppercase tracking-[0.3em] font-bold opacity-40">{selectedBrand.subtitle}</p>
                    </div>
                    <h2 className="text-6xl md:text-8xl italic leading-none">{selectedBrand.title}</h2>
                  </motion.div>
                  
                  <motion.div
                    initial={{ opacity: 0, filter: "blur(10px)", y: 20 }}
                    animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                    transition={{ delay: 0.3, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className="space-y-8"
                  >
                    <p className="text-xl md:text-2xl font-light leading-relaxed opacity-80">
                      {selectedBrand.description}
                    </p>

                    <div className="grid sm:grid-cols-2 gap-6 pt-8">
                      {selectedBrand.details.map((detail, i) => (
                        <motion.div 
                          key={i}
                          initial={{ opacity: 0, filter: "blur(8px)", y: 10 }}
                          whileInView={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                          transition={{ delay: 0.3 + (i * 0.05), duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                          className={`flex items-center gap-4 p-6 rounded-3xl border border-blackout/5 ${selectedBrand.accentBorder} transition-colors bg-white/40 backdrop-blur-sm`}
                        >
                          <div className={`w-2 h-2 rounded-full ${selectedBrand.color}`} />
                          <span className="text-sm font-medium tracking-wide">{detail}</span>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, filter: "blur(15px)", y: 20 }}
                    animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                    transition={{ delay: 0.5, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className="pt-12"
                  >
                    <button 
                      className={`w-full sm:w-auto px-12 py-5 rounded-full ${selectedBrand.color} ${selectedBrand.textColor} text-xs uppercase tracking-[0.3em] font-bold hover:scale-105 transition-all shadow-xl ${selectedBrand.accentShadow}`}
                    >
                      Reservar Experiência {selectedBrand.id}
                    </button>
                  </motion.div>
                </div>
                
                <motion.div 
                  initial={{ scale: 0.98, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.4, duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                  className="relative aspect-[4/5] lg:aspect-square rounded-[3rem] overflow-hidden shadow-2xl sticky top-12"
                >
                  <motion.img 
                    layoutId={`img-${selectedBrand.id}`}
                    src={selectedBrand.image} 
                    alt={selectedBrand.title}
                    className="object-cover w-full h-full"
                    referrerPolicy="no-referrer"
                    transition={sharedTransition}
                  />
                  <motion.div 
                    layoutId={`overlay-${selectedBrand.id}`}
                    className={`absolute inset-0 opacity-30 ${selectedBrand.gradient}`} 
                    transition={sharedTransition}
                  />
                  
                  {/* Floating Badge */}
                  <div className="absolute bottom-8 left-8 right-8 p-8 backdrop-blur-xl bg-white/10 border border-white/20 rounded-3xl">
                    <p className="text-white text-sm font-light italic leading-relaxed">
                      "A autenticidade é o centro de tudo o que criamos no ecossistema LUNES."
                    </p>
                  </div>
                </motion.div>
              </div>

              {/* Editorial Image Gallery (Horizontal Scroll) */}
              <div className="py-32 overflow-hidden border-t border-blackout/5">
                <div className="max-w-7xl mx-auto px-8 md:px-16 mb-16">
                  <div className="space-y-4">
                    <h3 className="text-3xl font-light italic">Galeria de Experiências</h3>
                    <p className="text-sm text-blackout/60 max-w-md">
                      Um vislumbre dos momentos e ambientes que definem a essência {selectedBrand.title}.
                    </p>
                  </div>
                </div>

                <motion.div 
                  className="flex gap-12 px-8 md:px-16 cursor-grab active:cursor-grabbing"
                  drag="x"
                  dragConstraints={{ right: 0, left: -1200 }}
                >
                  {selectedBrand.gallery.map((img, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, filter: "blur(20px)" }}
                      whileInView={{ opacity: 1, filter: "blur(0px)" }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1, duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                      className={`relative flex-shrink-0 rounded-[2.5rem] overflow-hidden bg-blackout/5 ${
                        idx % 2 === 0 ? 'w-[400px] h-[500px] mt-12' : 'w-[500px] h-[400px]'
                      }`}
                    >
                      <img 
                        src={img} 
                        alt={`${selectedBrand.title} Gallery ${idx + 1}`}
                        className="object-cover w-full h-full transition-transform duration-700 hover:scale-110"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute bottom-6 left-6">
                        <span className="text-[10px] uppercase tracking-widest text-white/40">0{idx + 1}</span>
                      </div>
                    </motion.div>
                  ))}
                  {/* Extra spacer for scroll */}
                  <div className="w-32 flex-shrink-0" />
                </motion.div>
              </div>
              
              {/* Footer */}
              <div className="p-12 border-t border-blackout/5 text-center opacity-30 text-[10px] uppercase tracking-[0.5em]">
                Lunes Ecosystem &copy; 2026
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Scroll to Top Button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, filter: "blur(10px)", scale: 0.8 }}
            animate={{ opacity: 1, filter: "blur(0px)", scale: 1 }}
            exit={{ opacity: 0, filter: "blur(10px)", scale: 0.8 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-8 right-8 z-[100] p-4 rounded-full bg-blackout text-coconut shadow-2xl border border-coconut/10 backdrop-blur-md hover:bg-blackout/90 transition-colors group"
          >
            <ArrowUp className="w-5 h-5 group-hover:-translate-y-1 transition-transform" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
